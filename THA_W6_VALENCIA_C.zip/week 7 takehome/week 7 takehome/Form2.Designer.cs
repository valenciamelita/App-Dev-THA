﻿namespace week_7_takehome
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.button_q = new System.Windows.Forms.Button();
            this.button_w = new System.Windows.Forms.Button();
            this.button_e = new System.Windows.Forms.Button();
            this.button_r = new System.Windows.Forms.Button();
            this.button_t = new System.Windows.Forms.Button();
            this.button_y = new System.Windows.Forms.Button();
            this.button_u = new System.Windows.Forms.Button();
            this.button_i = new System.Windows.Forms.Button();
            this.button_o = new System.Windows.Forms.Button();
            this.button_p = new System.Windows.Forms.Button();
            this.button_a = new System.Windows.Forms.Button();
            this.button_s = new System.Windows.Forms.Button();
            this.button_d = new System.Windows.Forms.Button();
            this.button_h = new System.Windows.Forms.Button();
            this.button_f = new System.Windows.Forms.Button();
            this.button_g = new System.Windows.Forms.Button();
            this.button_j = new System.Windows.Forms.Button();
            this.button_k = new System.Windows.Forms.Button();
            this.button_l = new System.Windows.Forms.Button();
            this.button_z = new System.Windows.Forms.Button();
            this.button_x = new System.Windows.Forms.Button();
            this.button_b = new System.Windows.Forms.Button();
            this.button_c = new System.Windows.Forms.Button();
            this.button_v = new System.Windows.Forms.Button();
            this.button_n = new System.Windows.Forms.Button();
            this.button_m = new System.Windows.Forms.Button();
            this.button_enter = new System.Windows.Forms.Button();
            this.button_delete = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // button_q
            // 
            this.button_q.Location = new System.Drawing.Point(496, 101);
            this.button_q.Name = "button_q";
            this.button_q.Size = new System.Drawing.Size(68, 68);
            this.button_q.TabIndex = 0;
            this.button_q.Text = "Q";
            this.button_q.UseVisualStyleBackColor = true;
            this.button_q.Click += new System.EventHandler(this.buttonkey_Click);
            // 
            // button_w
            // 
            this.button_w.Location = new System.Drawing.Point(570, 101);
            this.button_w.Name = "button_w";
            this.button_w.Size = new System.Drawing.Size(68, 68);
            this.button_w.TabIndex = 1;
            this.button_w.Text = "W";
            this.button_w.UseVisualStyleBackColor = true;
            this.button_w.Click += new System.EventHandler(this.buttonkey_Click);
            // 
            // button_e
            // 
            this.button_e.Location = new System.Drawing.Point(644, 101);
            this.button_e.Name = "button_e";
            this.button_e.Size = new System.Drawing.Size(68, 68);
            this.button_e.TabIndex = 2;
            this.button_e.Text = "E";
            this.button_e.UseVisualStyleBackColor = true;
            this.button_e.Click += new System.EventHandler(this.buttonkey_Click);
            // 
            // button_r
            // 
            this.button_r.Location = new System.Drawing.Point(718, 101);
            this.button_r.Name = "button_r";
            this.button_r.Size = new System.Drawing.Size(68, 68);
            this.button_r.TabIndex = 3;
            this.button_r.Text = "R";
            this.button_r.UseVisualStyleBackColor = true;
            this.button_r.Click += new System.EventHandler(this.buttonkey_Click);
            // 
            // button_t
            // 
            this.button_t.Location = new System.Drawing.Point(792, 101);
            this.button_t.Name = "button_t";
            this.button_t.Size = new System.Drawing.Size(68, 68);
            this.button_t.TabIndex = 4;
            this.button_t.Text = "T";
            this.button_t.UseVisualStyleBackColor = true;
            this.button_t.Click += new System.EventHandler(this.buttonkey_Click);
            // 
            // button_y
            // 
            this.button_y.Location = new System.Drawing.Point(866, 101);
            this.button_y.Name = "button_y";
            this.button_y.Size = new System.Drawing.Size(68, 68);
            this.button_y.TabIndex = 5;
            this.button_y.Text = "Y";
            this.button_y.UseVisualStyleBackColor = true;
            this.button_y.Click += new System.EventHandler(this.buttonkey_Click);
            // 
            // button_u
            // 
            this.button_u.Location = new System.Drawing.Point(940, 101);
            this.button_u.Name = "button_u";
            this.button_u.Size = new System.Drawing.Size(68, 68);
            this.button_u.TabIndex = 6;
            this.button_u.Text = "U";
            this.button_u.UseVisualStyleBackColor = true;
            this.button_u.Click += new System.EventHandler(this.buttonkey_Click);
            // 
            // button_i
            // 
            this.button_i.Location = new System.Drawing.Point(1014, 101);
            this.button_i.Name = "button_i";
            this.button_i.Size = new System.Drawing.Size(68, 68);
            this.button_i.TabIndex = 7;
            this.button_i.Text = "I";
            this.button_i.UseVisualStyleBackColor = true;
            this.button_i.Click += new System.EventHandler(this.buttonkey_Click);
            // 
            // button_o
            // 
            this.button_o.Location = new System.Drawing.Point(1088, 101);
            this.button_o.Name = "button_o";
            this.button_o.Size = new System.Drawing.Size(68, 68);
            this.button_o.TabIndex = 8;
            this.button_o.Text = "O";
            this.button_o.UseVisualStyleBackColor = true;
            this.button_o.Click += new System.EventHandler(this.buttonkey_Click);
            // 
            // button_p
            // 
            this.button_p.Location = new System.Drawing.Point(1162, 101);
            this.button_p.Name = "button_p";
            this.button_p.Size = new System.Drawing.Size(68, 68);
            this.button_p.TabIndex = 9;
            this.button_p.Text = "P";
            this.button_p.UseVisualStyleBackColor = true;
            this.button_p.Click += new System.EventHandler(this.buttonkey_Click);
            // 
            // button_a
            // 
            this.button_a.Location = new System.Drawing.Point(535, 175);
            this.button_a.Name = "button_a";
            this.button_a.Size = new System.Drawing.Size(68, 68);
            this.button_a.TabIndex = 10;
            this.button_a.Text = "A";
            this.button_a.UseVisualStyleBackColor = true;
            this.button_a.Click += new System.EventHandler(this.buttonkey_Click);
            // 
            // button_s
            // 
            this.button_s.Location = new System.Drawing.Point(609, 175);
            this.button_s.Name = "button_s";
            this.button_s.Size = new System.Drawing.Size(68, 68);
            this.button_s.TabIndex = 11;
            this.button_s.Text = "S";
            this.button_s.UseVisualStyleBackColor = true;
            this.button_s.Click += new System.EventHandler(this.buttonkey_Click);
            // 
            // button_d
            // 
            this.button_d.Location = new System.Drawing.Point(683, 175);
            this.button_d.Name = "button_d";
            this.button_d.Size = new System.Drawing.Size(68, 68);
            this.button_d.TabIndex = 12;
            this.button_d.Text = "D";
            this.button_d.UseVisualStyleBackColor = true;
            this.button_d.Click += new System.EventHandler(this.buttonkey_Click);
            // 
            // button_h
            // 
            this.button_h.Location = new System.Drawing.Point(905, 175);
            this.button_h.Name = "button_h";
            this.button_h.Size = new System.Drawing.Size(68, 68);
            this.button_h.TabIndex = 13;
            this.button_h.Text = "H";
            this.button_h.UseVisualStyleBackColor = true;
            this.button_h.Click += new System.EventHandler(this.buttonkey_Click);
            // 
            // button_f
            // 
            this.button_f.Location = new System.Drawing.Point(757, 175);
            this.button_f.Name = "button_f";
            this.button_f.Size = new System.Drawing.Size(68, 68);
            this.button_f.TabIndex = 14;
            this.button_f.Text = "F";
            this.button_f.UseVisualStyleBackColor = true;
            this.button_f.Click += new System.EventHandler(this.buttonkey_Click);
            // 
            // button_g
            // 
            this.button_g.Location = new System.Drawing.Point(831, 175);
            this.button_g.Name = "button_g";
            this.button_g.Size = new System.Drawing.Size(68, 68);
            this.button_g.TabIndex = 15;
            this.button_g.Text = "G";
            this.button_g.UseVisualStyleBackColor = true;
            this.button_g.Click += new System.EventHandler(this.buttonkey_Click);
            // 
            // button_j
            // 
            this.button_j.Location = new System.Drawing.Point(979, 175);
            this.button_j.Name = "button_j";
            this.button_j.Size = new System.Drawing.Size(68, 68);
            this.button_j.TabIndex = 16;
            this.button_j.Text = "J";
            this.button_j.UseVisualStyleBackColor = true;
            this.button_j.Click += new System.EventHandler(this.buttonkey_Click);
            // 
            // button_k
            // 
            this.button_k.Location = new System.Drawing.Point(1053, 175);
            this.button_k.Name = "button_k";
            this.button_k.Size = new System.Drawing.Size(68, 68);
            this.button_k.TabIndex = 17;
            this.button_k.Text = "K";
            this.button_k.UseVisualStyleBackColor = true;
            this.button_k.Click += new System.EventHandler(this.buttonkey_Click);
            // 
            // button_l
            // 
            this.button_l.Location = new System.Drawing.Point(1127, 175);
            this.button_l.Name = "button_l";
            this.button_l.Size = new System.Drawing.Size(68, 68);
            this.button_l.TabIndex = 18;
            this.button_l.Text = "L";
            this.button_l.UseVisualStyleBackColor = true;
            this.button_l.Click += new System.EventHandler(this.buttonkey_Click);
            // 
            // button_z
            // 
            this.button_z.Location = new System.Drawing.Point(609, 249);
            this.button_z.Name = "button_z";
            this.button_z.Size = new System.Drawing.Size(68, 68);
            this.button_z.TabIndex = 19;
            this.button_z.Text = "Z";
            this.button_z.UseVisualStyleBackColor = true;
            this.button_z.Click += new System.EventHandler(this.buttonkey_Click);
            // 
            // button_x
            // 
            this.button_x.Location = new System.Drawing.Point(683, 249);
            this.button_x.Name = "button_x";
            this.button_x.Size = new System.Drawing.Size(68, 68);
            this.button_x.TabIndex = 20;
            this.button_x.Text = "X";
            this.button_x.UseVisualStyleBackColor = true;
            this.button_x.Click += new System.EventHandler(this.buttonkey_Click);
            // 
            // button_b
            // 
            this.button_b.Location = new System.Drawing.Point(905, 249);
            this.button_b.Name = "button_b";
            this.button_b.Size = new System.Drawing.Size(68, 68);
            this.button_b.TabIndex = 21;
            this.button_b.Text = "B";
            this.button_b.UseVisualStyleBackColor = true;
            this.button_b.Click += new System.EventHandler(this.buttonkey_Click);
            // 
            // button_c
            // 
            this.button_c.Location = new System.Drawing.Point(757, 249);
            this.button_c.Name = "button_c";
            this.button_c.Size = new System.Drawing.Size(68, 68);
            this.button_c.TabIndex = 22;
            this.button_c.Text = "C";
            this.button_c.UseVisualStyleBackColor = true;
            this.button_c.Click += new System.EventHandler(this.buttonkey_Click);
            // 
            // button_v
            // 
            this.button_v.Location = new System.Drawing.Point(831, 249);
            this.button_v.Name = "button_v";
            this.button_v.Size = new System.Drawing.Size(68, 68);
            this.button_v.TabIndex = 23;
            this.button_v.Text = "V";
            this.button_v.UseVisualStyleBackColor = true;
            this.button_v.Click += new System.EventHandler(this.buttonkey_Click);
            // 
            // button_n
            // 
            this.button_n.Location = new System.Drawing.Point(979, 249);
            this.button_n.Name = "button_n";
            this.button_n.Size = new System.Drawing.Size(68, 68);
            this.button_n.TabIndex = 24;
            this.button_n.Text = "N";
            this.button_n.UseVisualStyleBackColor = true;
            this.button_n.Click += new System.EventHandler(this.buttonkey_Click);
            // 
            // button_m
            // 
            this.button_m.Location = new System.Drawing.Point(1053, 249);
            this.button_m.Name = "button_m";
            this.button_m.Size = new System.Drawing.Size(68, 68);
            this.button_m.TabIndex = 25;
            this.button_m.Text = "M";
            this.button_m.UseVisualStyleBackColor = true;
            this.button_m.Click += new System.EventHandler(this.buttonkey_Click);
            // 
            // button_enter
            // 
            this.button_enter.Location = new System.Drawing.Point(479, 256);
            this.button_enter.Name = "button_enter";
            this.button_enter.Size = new System.Drawing.Size(124, 61);
            this.button_enter.TabIndex = 26;
            this.button_enter.Text = "Enter";
            this.button_enter.UseVisualStyleBackColor = true;
            this.button_enter.Click += new System.EventHandler(this.button_enter_Click);
            // 
            // button_delete
            // 
            this.button_delete.Location = new System.Drawing.Point(1127, 253);
            this.button_delete.Name = "button_delete";
            this.button_delete.Size = new System.Drawing.Size(124, 61);
            this.button_delete.TabIndex = 27;
            this.button_delete.Text = "Delete";
            this.button_delete.UseVisualStyleBackColor = true;
            this.button_delete.Click += new System.EventHandler(this.button_delete_Click);
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1408, 656);
            this.Controls.Add(this.button_delete);
            this.Controls.Add(this.button_enter);
            this.Controls.Add(this.button_m);
            this.Controls.Add(this.button_n);
            this.Controls.Add(this.button_v);
            this.Controls.Add(this.button_c);
            this.Controls.Add(this.button_b);
            this.Controls.Add(this.button_x);
            this.Controls.Add(this.button_z);
            this.Controls.Add(this.button_l);
            this.Controls.Add(this.button_k);
            this.Controls.Add(this.button_j);
            this.Controls.Add(this.button_g);
            this.Controls.Add(this.button_f);
            this.Controls.Add(this.button_h);
            this.Controls.Add(this.button_d);
            this.Controls.Add(this.button_s);
            this.Controls.Add(this.button_a);
            this.Controls.Add(this.button_p);
            this.Controls.Add(this.button_o);
            this.Controls.Add(this.button_i);
            this.Controls.Add(this.button_u);
            this.Controls.Add(this.button_y);
            this.Controls.Add(this.button_t);
            this.Controls.Add(this.button_r);
            this.Controls.Add(this.button_e);
            this.Controls.Add(this.button_w);
            this.Controls.Add(this.button_q);
            this.Name = "Form2";
            this.Text = "Form2";
            this.Load += new System.EventHandler(this.Form2_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button button_q;
        private System.Windows.Forms.Button button_w;
        private System.Windows.Forms.Button button_e;
        private System.Windows.Forms.Button button_r;
        private System.Windows.Forms.Button button_t;
        private System.Windows.Forms.Button button_y;
        private System.Windows.Forms.Button button_u;
        private System.Windows.Forms.Button button_i;
        private System.Windows.Forms.Button button_o;
        private System.Windows.Forms.Button button_p;
        private System.Windows.Forms.Button button_a;
        private System.Windows.Forms.Button button_s;
        private System.Windows.Forms.Button button_d;
        private System.Windows.Forms.Button button_h;
        private System.Windows.Forms.Button button_f;
        private System.Windows.Forms.Button button_g;
        private System.Windows.Forms.Button button_j;
        private System.Windows.Forms.Button button_k;
        private System.Windows.Forms.Button button_l;
        private System.Windows.Forms.Button button_z;
        private System.Windows.Forms.Button button_x;
        private System.Windows.Forms.Button button_b;
        private System.Windows.Forms.Button button_c;
        private System.Windows.Forms.Button button_v;
        private System.Windows.Forms.Button button_n;
        private System.Windows.Forms.Button button_m;
        private System.Windows.Forms.Button button_enter;
        private System.Windows.Forms.Button button_delete;
    }
}