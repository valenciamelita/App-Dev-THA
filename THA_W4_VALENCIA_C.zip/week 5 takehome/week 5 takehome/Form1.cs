﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace week_5_takehome
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        public class Team
        {
            public string teamname { get; set; }
            public string teamcountry { get; set; }
            public string teamcity { get; set; }

            private List<Player> players = new List<Player>();

            public void addplayer(string playernum, string playername, string playerpos)
            {
                Player item = new Player();
                item.playernum = playernum;
                item.playername = playername;
                item.playerpos = playerpos;
                players.Add(item);
            }

            public List<Player> Players
            {
                get { return players; }
                set { players = value; }
            }

        }

        public class Player
        {
            public string playername { get; set; }
            public string playernum { get; set; }
            public string playerpos { get; set; }
        }

        public List<Team> teams = new List<Team>();


        private void Form1_Load(object sender, EventArgs e)
        {
            listbox_show.Sorted = true;

            Team teamsatu = new Team();
            teamsatu.teamname = "Tottenham Hotspur F.C";
            teamsatu.teamcountry = "England";
            teamsatu.teamcity = "Tottenham";
            Team item = teamsatu;
            item.addplayer("01", "Hugo Lloris", "GK");
            item.addplayer("04", "Oliver Skipp", "MF");
            item.addplayer("05", "Pierre Emile Hojbjerg", "MF");
            item.addplayer("06", "Davinson Sanchez", "DF");
            item.addplayer("07", "Son Heung-Min", "FW");
            item.addplayer("09", "Richarlison", "DF");
            item.addplayer("10", "Harry Kane", "FW");
            item.addplayer("12", "Emerson Royal", "MF");
            item.addplayer("14", "Ivan Perisic", "MF");
            item.addplayer("15", "Eric Dier", "DF");
            item.addplayer("17", "Cristian Romero", "MF");
            teams.Add(item);
            Team teamdua = new Team();
            teamdua.teamname = "Chelsea F.C";
            teamdua.teamcountry = "England";
            teamdua.teamcity = "Fulham";
            item = teamdua;
            item.addplayer("01", "Kepa Arrizabalaga", "GK");
            item.addplayer("04", "Beno\x00eet Badiashile", "DF");
            item.addplayer("05", "Enzo Fern\x00e1ndez", "MF");
            item.addplayer("06", "Thiago Silva", "DF");
            item.addplayer("07", "N'Golo Kant\x00e9", "MF");
            item.addplayer("08", "Mateo Kovačić", "MF");
            item.addplayer("10", "Christian Pulisic", "MF");
            item.addplayer("11", "Jo\x00e3o F\x00e9lix", "FW");
            item.addplayer("17", "Raheem Sterling", "MF");
            item.addplayer("19", "Mason Mount", "MF");
            item.addplayer("21", "Ben Chilwell", "MF");
            teams.Add(item);
            Team teamtiga = new Team();
            teamtiga.teamname = "Barcelona F.C";
            teamtiga.teamcountry = "Spain";
            teamtiga.teamcity = "Barcelona";
            item = teamtiga;
            item.addplayer("01", "Marc Andre ter Stegen", "GK");
            item.addplayer("04", "Ronald Araujo", "DF");
            item.addplayer("05", "Sergio Busquets", "MF");
            item.addplayer("06", "Pablo Gavi", "MF");
            item.addplayer("07", "Ousmane Dembele", "FW");
            item.addplayer("08", "Pedri", "MF");
            item.addplayer("10", "Ansu Fati", "FW");
            item.addplayer("11", "Ferran Torres", "FW");
            item.addplayer("18", "Jordi Alba", "DF");
            item.addplayer("20", "Sergi Roberto", "MF");
            item.addplayer("21", "Frenkie deJong", "MF");
            teams.Add(item);
            

        }

        private void combobox_country_SelectedIndexChanged(object sender, EventArgs e)
        {

            combobox_chooseteam.Items.Clear();
            string abc = combobox_country.SelectedItem.ToString();
            foreach (Team team in teams)
            {
                if (team.teamcountry == abc)
                {
                    combobox_chooseteam.Items.Add(team.teamname);
                }
            }

        }

        private void combobox_chooseteam_SelectedIndexChanged(object sender, EventArgs e)
        {
            listbox_show.Items.Clear();
            string nama = combobox_chooseteam.SelectedItem.ToString();
            Team team = new Team();
            foreach (Team teamm in teams)
            {
                if (teamm.teamname == nama)
                {
                    team = teamm;
                }
            }
            foreach (Player player in team.Players)
            {

                string haha = "(" + player.playernum + ") " + player.playername + ", " + player.playerpos;
                listbox_show.Items.Add(haha);
            }
        }

        private void button_addteam_Click(object sender, EventArgs e)
        {
            if (textbox_teamcountry.Text == "" || textbox_teamname.Text == "" || textbox_teamcity.Text == "")
            {
                MessageBox.Show("All Fields Need to be Filled!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else
            {
                string nama = textbox_teamname.Text;
                string kota = textbox_teamcity.Text;
                string negara = textbox_teamcountry.Text;
                bool teamexists = false;
                foreach (Team team in teams)
                {
                    if (team.teamname == nama)
                    {
                        teamexists = true;
                        break;
                    }
                }
                if (teamexists)
                {
                    MessageBox.Show("Team cannot be same!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }

                if (teamexists == false)
                {
                    Team item = new Team();
                    item.teamname = nama;
                    item.teamcity = kota;
                    item.teamcountry = negara;
                    teams.Add(item);
                }
                combobox_country.Items.Clear();
                foreach (Team team in teams)
                {
                    if (combobox_country.Items.Contains(team.teamcountry) == false)
                    {
                        combobox_country.Items.Add(team.teamcountry);
                    }
                }
                textbox_teamcity.Clear();
                textbox_teamcountry.Clear();
                textbox_teamname.Clear();
            }


        }
        private void button_addplayer_Click(object sender, EventArgs e)
        {
            if (textbox_playername.Text == "" || textbox_playernum.Text == "" || combobox_playerpos.SelectedIndex == -1)
            {
                MessageBox.Show("All Fields Need to be Filled", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);

            }
            else
            {
                string selectedteam = combobox_chooseteam.SelectedItem.ToString();
                foreach (Team teamm in teams)
                {
                    if (teamm.teamname==selectedteam)
                    {
                        bool nomerada = false;
                        bool namaada = false;
                        foreach (Player player in teamm.Players)
                        {
                            if (player.playernum == textbox_playernum.Text)
                            {
                                nomerada = true;
                                break;
                            }
                            if (player.playername == textbox_playername.Text)
                            {
                                namaada = true;
                                break;
                            }
                        }
                        if (nomerada == false && namaada == false)
                        {
                            teamm.addplayer(textbox_playernum.Text, textbox_playername.Text, combobox_playerpos.SelectedItem.ToString());
                        }
                        else if (nomerada == true)
                        {
                            MessageBox.Show("Player with Same Number is found", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        }
                        else if(namaada == true)
                        {
                            MessageBox.Show("Player with Same Name is found", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        }
                    }

                }
                listbox_show.Items.Clear();
                string nama = combobox_chooseteam.SelectedItem.ToString();
                Team team = new Team();
                foreach (Team teamm in teams)
                {
                    if (teamm.teamname == nama)
                    {
                        team = teamm;
                    }
                }
                foreach (Player player in team.Players)
                {

                    string haha = "(" + player.playernum + ") " + player.playername + ", " + player.playerpos;
                    listbox_show.Items.Add(haha);
                }
            }
            textbox_playername.Clear();
            textbox_playernum.Clear();


        }

        private void removePlayerFromTeam(Team team, Player player)
        {
            team.Players.Remove(player);
        }

        private void button_remove_Click(object sender, EventArgs e)
        {
            string selectedteam = combobox_chooseteam.SelectedItem.ToString();
            
                foreach (Team teamlagi in teams)
                {
                    if (teamlagi.teamname == selectedteam)
                    {
                        if (teamlagi.Players.Count <= 11)
                        {
                            MessageBox.Show("Unable to Remove Players if Players less than 11", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                            continue;
                        }
                    }


                    string[] pisah = listbox_show.SelectedItem.ToString().Split(',');
                    string[] pisah2 = pisah[0].Split(')');
                    string nomer = pisah2[0].Substring(0);
                    string name = pisah2[1].Substring(1);
                    bool benar = true;

                    while (benar)
                    {
                        foreach (Player player in teamlagi.Players)
                        {
                            if (player.playername == name)
                            {
                                teamlagi.Players.Remove(player);
                                benar = false;
                                break;
                                
                            }
                        }
                        break;
                    }

                }

            listbox_show.Items.Clear();
            string nama = combobox_chooseteam.SelectedItem.ToString();
            Team team = new Team();
            foreach (Team teamm in teams)
            {
                if (teamm.teamname == nama)
                {
                    team = teamm;
                }
            }
            foreach (Player player in team.Players)
            {

                string haha = "(" + player.playernum + ") " + player.playername + ", " + player.playerpos;
                listbox_show.Items.Add(haha);
            }
        }
    }
}

