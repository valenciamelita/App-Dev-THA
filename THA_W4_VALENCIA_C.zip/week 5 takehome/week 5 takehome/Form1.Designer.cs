﻿namespace week_5_takehome
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label_teamlist = new System.Windows.Forms.Label();
            this.label_choosecon = new System.Windows.Forms.Label();
            this.label_chooseteam = new System.Windows.Forms.Label();
            this.combobox_country = new System.Windows.Forms.ComboBox();
            this.combobox_chooseteam = new System.Windows.Forms.ComboBox();
            this.listbox_show = new System.Windows.Forms.ListBox();
            this.label_addteam = new System.Windows.Forms.Label();
            this.label_addplayers = new System.Windows.Forms.Label();
            this.label_teamname = new System.Windows.Forms.Label();
            this.label_teamcountry = new System.Windows.Forms.Label();
            this.label_teamcity = new System.Windows.Forms.Label();
            this.textbox_teamname = new System.Windows.Forms.TextBox();
            this.textbox_teamcountry = new System.Windows.Forms.TextBox();
            this.textbox_teamcity = new System.Windows.Forms.TextBox();
            this.button_addteam = new System.Windows.Forms.Button();
            this.button_addplayer = new System.Windows.Forms.Button();
            this.textbox_playernum = new System.Windows.Forms.TextBox();
            this.textbox_playername = new System.Windows.Forms.TextBox();
            this.label_playerposition = new System.Windows.Forms.Label();
            this.label_playernum = new System.Windows.Forms.Label();
            this.label_playername = new System.Windows.Forms.Label();
            this.button_remove = new System.Windows.Forms.Button();
            this.combobox_playerpos = new System.Windows.Forms.ComboBox();
            this.SuspendLayout();
            // 
            // label_teamlist
            // 
            this.label_teamlist.AutoSize = true;
            this.label_teamlist.Font = new System.Drawing.Font("Century", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_teamlist.Location = new System.Drawing.Point(12, 72);
            this.label_teamlist.Name = "label_teamlist";
            this.label_teamlist.Size = new System.Drawing.Size(204, 28);
            this.label_teamlist.TabIndex = 0;
            this.label_teamlist.Text = "Soccer Team List";
            // 
            // label_choosecon
            // 
            this.label_choosecon.AutoSize = true;
            this.label_choosecon.Location = new System.Drawing.Point(12, 123);
            this.label_choosecon.Name = "label_choosecon";
            this.label_choosecon.Size = new System.Drawing.Size(127, 20);
            this.label_choosecon.TabIndex = 1;
            this.label_choosecon.Text = "Choose Country:";
            // 
            // label_chooseteam
            // 
            this.label_chooseteam.AutoSize = true;
            this.label_chooseteam.Location = new System.Drawing.Point(12, 166);
            this.label_chooseteam.Name = "label_chooseteam";
            this.label_chooseteam.Size = new System.Drawing.Size(112, 20);
            this.label_chooseteam.TabIndex = 2;
            this.label_chooseteam.Text = "Choose Team:";
            // 
            // combobox_country
            // 
            this.combobox_country.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.combobox_country.FormattingEnabled = true;
            this.combobox_country.Items.AddRange(new object[] {
            "England",
            "Spain"});
            this.combobox_country.Location = new System.Drawing.Point(161, 120);
            this.combobox_country.Name = "combobox_country";
            this.combobox_country.Size = new System.Drawing.Size(167, 28);
            this.combobox_country.TabIndex = 3;
            this.combobox_country.SelectedIndexChanged += new System.EventHandler(this.combobox_country_SelectedIndexChanged);
            // 
            // combobox_chooseteam
            // 
            this.combobox_chooseteam.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.combobox_chooseteam.FormattingEnabled = true;
            this.combobox_chooseteam.Location = new System.Drawing.Point(161, 166);
            this.combobox_chooseteam.Name = "combobox_chooseteam";
            this.combobox_chooseteam.Size = new System.Drawing.Size(167, 28);
            this.combobox_chooseteam.TabIndex = 4;
            this.combobox_chooseteam.SelectedIndexChanged += new System.EventHandler(this.combobox_chooseteam_SelectedIndexChanged);
            // 
            // listbox_show
            // 
            this.listbox_show.FormattingEnabled = true;
            this.listbox_show.ItemHeight = 20;
            this.listbox_show.Location = new System.Drawing.Point(17, 229);
            this.listbox_show.Name = "listbox_show";
            this.listbox_show.Size = new System.Drawing.Size(311, 184);
            this.listbox_show.TabIndex = 5;
            // 
            // label_addteam
            // 
            this.label_addteam.AutoSize = true;
            this.label_addteam.Font = new System.Drawing.Font("Century", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_addteam.Location = new System.Drawing.Point(489, 72);
            this.label_addteam.Name = "label_addteam";
            this.label_addteam.Size = new System.Drawing.Size(162, 28);
            this.label_addteam.TabIndex = 6;
            this.label_addteam.Text = "Adding Team";
            // 
            // label_addplayers
            // 
            this.label_addplayers.AutoSize = true;
            this.label_addplayers.Font = new System.Drawing.Font("Century", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_addplayers.Location = new System.Drawing.Point(806, 72);
            this.label_addplayers.Name = "label_addplayers";
            this.label_addplayers.Size = new System.Drawing.Size(184, 28);
            this.label_addplayers.TabIndex = 7;
            this.label_addplayers.Text = "Adding Players";
            // 
            // label_teamname
            // 
            this.label_teamname.AutoSize = true;
            this.label_teamname.Location = new System.Drawing.Point(353, 123);
            this.label_teamname.Name = "label_teamname";
            this.label_teamname.Size = new System.Drawing.Size(99, 20);
            this.label_teamname.TabIndex = 8;
            this.label_teamname.Text = "Team Name:";
            // 
            // label_teamcountry
            // 
            this.label_teamcountry.AutoSize = true;
            this.label_teamcountry.Location = new System.Drawing.Point(353, 166);
            this.label_teamcountry.Name = "label_teamcountry";
            this.label_teamcountry.Size = new System.Drawing.Size(112, 20);
            this.label_teamcountry.TabIndex = 9;
            this.label_teamcountry.Text = "Team Country:";
            // 
            // label_teamcity
            // 
            this.label_teamcity.AutoSize = true;
            this.label_teamcity.Location = new System.Drawing.Point(353, 206);
            this.label_teamcity.Name = "label_teamcity";
            this.label_teamcity.Size = new System.Drawing.Size(83, 20);
            this.label_teamcity.TabIndex = 10;
            this.label_teamcity.Text = "Team City:";
            // 
            // textbox_teamname
            // 
            this.textbox_teamname.Location = new System.Drawing.Point(477, 120);
            this.textbox_teamname.Name = "textbox_teamname";
            this.textbox_teamname.Size = new System.Drawing.Size(187, 26);
            this.textbox_teamname.TabIndex = 11;
            // 
            // textbox_teamcountry
            // 
            this.textbox_teamcountry.Location = new System.Drawing.Point(477, 163);
            this.textbox_teamcountry.Name = "textbox_teamcountry";
            this.textbox_teamcountry.Size = new System.Drawing.Size(187, 26);
            this.textbox_teamcountry.TabIndex = 12;
            // 
            // textbox_teamcity
            // 
            this.textbox_teamcity.Location = new System.Drawing.Point(477, 206);
            this.textbox_teamcity.Name = "textbox_teamcity";
            this.textbox_teamcity.Size = new System.Drawing.Size(187, 26);
            this.textbox_teamcity.TabIndex = 13;
            // 
            // button_addteam
            // 
            this.button_addteam.Location = new System.Drawing.Point(589, 258);
            this.button_addteam.Name = "button_addteam";
            this.button_addteam.Size = new System.Drawing.Size(75, 29);
            this.button_addteam.TabIndex = 14;
            this.button_addteam.Text = "Add";
            this.button_addteam.UseVisualStyleBackColor = true;
            this.button_addteam.Click += new System.EventHandler(this.button_addteam_Click);
            // 
            // button_addplayer
            // 
            this.button_addplayer.Location = new System.Drawing.Point(915, 255);
            this.button_addplayer.Name = "button_addplayer";
            this.button_addplayer.Size = new System.Drawing.Size(75, 29);
            this.button_addplayer.TabIndex = 21;
            this.button_addplayer.Text = "Add";
            this.button_addplayer.UseVisualStyleBackColor = true;
            this.button_addplayer.Click += new System.EventHandler(this.button_addplayer_Click);
            // 
            // textbox_playernum
            // 
            this.textbox_playernum.Location = new System.Drawing.Point(803, 160);
            this.textbox_playernum.Name = "textbox_playernum";
            this.textbox_playernum.Size = new System.Drawing.Size(187, 26);
            this.textbox_playernum.TabIndex = 19;
            // 
            // textbox_playername
            // 
            this.textbox_playername.Location = new System.Drawing.Point(803, 117);
            this.textbox_playername.Name = "textbox_playername";
            this.textbox_playername.Size = new System.Drawing.Size(187, 26);
            this.textbox_playername.TabIndex = 18;
            // 
            // label_playerposition
            // 
            this.label_playerposition.AutoSize = true;
            this.label_playerposition.Location = new System.Drawing.Point(679, 203);
            this.label_playerposition.Name = "label_playerposition";
            this.label_playerposition.Size = new System.Drawing.Size(116, 20);
            this.label_playerposition.TabIndex = 17;
            this.label_playerposition.Text = "Player Position:";
            // 
            // label_playernum
            // 
            this.label_playernum.AutoSize = true;
            this.label_playernum.Location = new System.Drawing.Point(678, 163);
            this.label_playernum.Name = "label_playernum";
            this.label_playernum.Size = new System.Drawing.Size(116, 20);
            this.label_playernum.TabIndex = 16;
            this.label_playernum.Text = "Player Number:";
            // 
            // label_playername
            // 
            this.label_playername.AutoSize = true;
            this.label_playername.Location = new System.Drawing.Point(679, 120);
            this.label_playername.Name = "label_playername";
            this.label_playername.Size = new System.Drawing.Size(102, 20);
            this.label_playername.TabIndex = 15;
            this.label_playername.Text = "Player Name:";
            // 
            // button_remove
            // 
            this.button_remove.Location = new System.Drawing.Point(17, 419);
            this.button_remove.Name = "button_remove";
            this.button_remove.Size = new System.Drawing.Size(107, 29);
            this.button_remove.TabIndex = 22;
            this.button_remove.Text = "Remove";
            this.button_remove.UseVisualStyleBackColor = true;
            this.button_remove.Click += new System.EventHandler(this.button_remove_Click);
            // 
            // combobox_playerpos
            // 
            this.combobox_playerpos.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.combobox_playerpos.FormattingEnabled = true;
            this.combobox_playerpos.Items.AddRange(new object[] {
            "GK",
            "DF",
            "MF",
            "FW"});
            this.combobox_playerpos.Location = new System.Drawing.Point(803, 198);
            this.combobox_playerpos.Name = "combobox_playerpos";
            this.combobox_playerpos.Size = new System.Drawing.Size(187, 28);
            this.combobox_playerpos.TabIndex = 23;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1002, 450);
            this.Controls.Add(this.combobox_playerpos);
            this.Controls.Add(this.button_remove);
            this.Controls.Add(this.button_addplayer);
            this.Controls.Add(this.textbox_playernum);
            this.Controls.Add(this.textbox_playername);
            this.Controls.Add(this.label_playerposition);
            this.Controls.Add(this.label_playernum);
            this.Controls.Add(this.label_playername);
            this.Controls.Add(this.button_addteam);
            this.Controls.Add(this.textbox_teamcity);
            this.Controls.Add(this.textbox_teamcountry);
            this.Controls.Add(this.textbox_teamname);
            this.Controls.Add(this.label_teamcity);
            this.Controls.Add(this.label_teamcountry);
            this.Controls.Add(this.label_teamname);
            this.Controls.Add(this.label_addplayers);
            this.Controls.Add(this.label_addteam);
            this.Controls.Add(this.listbox_show);
            this.Controls.Add(this.combobox_chooseteam);
            this.Controls.Add(this.combobox_country);
            this.Controls.Add(this.label_chooseteam);
            this.Controls.Add(this.label_choosecon);
            this.Controls.Add(this.label_teamlist);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label_teamlist;
        private System.Windows.Forms.Label label_choosecon;
        private System.Windows.Forms.Label label_chooseteam;
        private System.Windows.Forms.ComboBox combobox_country;
        private System.Windows.Forms.ComboBox combobox_chooseteam;
        private System.Windows.Forms.ListBox listbox_show;
        private System.Windows.Forms.Label label_addteam;
        private System.Windows.Forms.Label label_addplayers;
        private System.Windows.Forms.Label label_teamname;
        private System.Windows.Forms.Label label_teamcountry;
        private System.Windows.Forms.Label label_teamcity;
        private System.Windows.Forms.TextBox textbox_teamname;
        private System.Windows.Forms.TextBox textbox_teamcountry;
        private System.Windows.Forms.TextBox textbox_teamcity;
        private System.Windows.Forms.Button button_addteam;
        private System.Windows.Forms.Button button_addplayer;
        private System.Windows.Forms.TextBox textbox_playernum;
        private System.Windows.Forms.TextBox textbox_playername;
        private System.Windows.Forms.Label label_playerposition;
        private System.Windows.Forms.Label label_playernum;
        private System.Windows.Forms.Label label_playername;
        private System.Windows.Forms.Button button_remove;
        private System.Windows.Forms.ComboBox combobox_playerpos;
    }
}

