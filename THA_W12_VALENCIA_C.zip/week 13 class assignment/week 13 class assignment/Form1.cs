﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml;
using MySql.Data.MySqlClient;

namespace week_13_class_assignment
{
    public partial class Form1 : Form
    {
        string connectionstring = "server=localhost;uid=root;pwd=junior123;database=premier_league";
        MySqlConnection conn;
        MySqlCommand cmd;
        MySqlDataAdapter adapter;
        MySqlDataReader sqlDataReader;
        string query;
        DataTable dt;
        DataTable dt2;
        DataTable dt3;
        DataTable dt4;
        DataTable dt5;
        DataTable dt6;
        DataTable dt7;

        public Form1()
        {
            try
            {
                string connection = "server=localhost;uid=root;pwd=junior123;database=premier_league";
                conn = new MySqlConnection(connection);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            InitializeComponent();

        }

        private void updateDgv2()
        {
            dt4.Clear();
            try
            {
                query = "select p.player_name, p.team_number, n.nation, p.playing_pos, p.height, p.weight, p.birthdate\r\nfrom player p, nationality n\r\nwhere p.nationality_id=n.nationality_id && p.status=1;";
                cmd = new MySqlCommand(query, conn);
                adapter = new MySqlDataAdapter(cmd);
                adapter.Fill(dt4);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void updateDgv1()
        {
            dt4.Clear();
            try
            {
                query = $"select p.player_name, p.team_number, n.nation, p.playing_pos, p.height, p.weight, p.birthdate, t.team_name\r\nfrom player p join nationality n on p.nationality_id=n.nationality_id\r\njoin team t on t.team_id=p.team_id\r\nwhere p.status=1;";
                cmd = new MySqlCommand(query, conn);
                adapter = new MySqlDataAdapter(cmd);
                adapter.Fill(dt4);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void updateDgvManager()
        {
            try
            {
                dt5.Clear();
                string team = combobox_teamname2.SelectedValue.ToString();
                query = $"select m.manager_id, m.manager_name, t.team_name, m.birthdate, n.nation\r\nfrom manager m, team t, nationality n\r\nwhere t.manager_id=m.manager_id && n.nationality_id=m.nationality_id && t.team_id = '{team}' && t.team_name is not null;";
                conn = new MySqlConnection(connectionstring);
                cmd = new MySqlCommand(query, conn);
                adapter = new MySqlDataAdapter(cmd);
                adapter.Fill(dt5);
                dgv_manager.DataSource = dt5;
                dgv_manager.ClearSelection();

                dt6.Clear();
                query = $"select m.manager_id, m.manager_name, n.nation, m.birthdate FROM manager m left join nationality n ON n.nationality_id = m.nationality_id WHERE m.working = 0;";
                cmd = new MySqlCommand(query, conn);
                adapter = new MySqlDataAdapter(cmd);
                adapter.Fill(dt6);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void executeSQL (string query)
        {
            try
            {
                conn.Open();
                cmd = new MySqlCommand(query, conn);
                sqlDataReader = cmd.ExecuteReader();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                conn.Close();
                updateDgv2();
            }
        }

        private void executeSQL2(string query)
        {
            try
            {
                conn.Open();
                cmd = new MySqlCommand(query, conn);
                sqlDataReader = cmd.ExecuteReader();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                conn.Close();
                updateDgv1();
            }
        }

        private void executeSQL3(string query)
        {
            try
            {
                conn.Open();
                cmd = new MySqlCommand(query, conn);
                sqlDataReader = cmd.ExecuteReader();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                conn.Close();
            }
        }


        private void Form1_Load(object sender, EventArgs e)
        {
           

                dt = new DataTable(); // isi combobox team name
                dt2 = new DataTable(); // isi combobox team name
                dt3 = new DataTable(); // isi combobox nationality
                dt4 = new DataTable(); // dgv no 1 & 3
                dt5 = new DataTable(); // dgv curr manager 
                dt6 = new DataTable(); // dgv all manager
                dt7 = new DataTable(); // isi combobox team name
                combobox_teamname3.SelectedIndexChanged -= combobox_teamname3_SelectedIndexChanged;
                combobox_teamname2.SelectedIndexChanged -= combobox_teamname2_SelectedIndexChanged;


                query = "select team_name, team_id from team;";
                conn = new MySqlConnection(connectionstring);
                cmd = new MySqlCommand(query, conn);
                adapter = new MySqlDataAdapter(cmd);
                adapter.Fill(dt);
                adapter.Fill(dt2);
                adapter.Fill(dt7);
                combobox_teamname.DataSource = dt;
                combobox_teamname2.DataSource = dt2;
                combobox_teamname3.DataSource = dt7;
                combobox_teamname.DisplayMember = "team_name";
                combobox_teamname2.DisplayMember = "team_name";
                combobox_teamname3.DisplayMember = "team_name";
                combobox_teamname2.ValueMember = "team_id";
                combobox_teamname.ValueMember = "team_id";
                combobox_teamname3.ValueMember = "team_id";
                combobox_teamname3.SelectedItem = null;
                combobox_teamname2.SelectedItem = null;
                combobox_teamname.SelectedItem = null;

                combobox_teamname3.SelectedIndexChanged += combobox_teamname3_SelectedIndexChanged;
                combobox_teamname2.SelectedIndexChanged += combobox_teamname2_SelectedIndexChanged;



                query = "select nation, nationality_id from nationality;";
                conn = new MySqlConnection(connectionstring);
                cmd = new MySqlCommand(query, conn);
                adapter = new MySqlDataAdapter(cmd);
                adapter.Fill(dt3);
                combobox_nationality.DataSource = dt3;
                combobox_nationality.DisplayMember = "nation";
                combobox_nationality.ValueMember = "nationality_id";

                query = "select p.player_name, p.team_number, n.nation, p.playing_pos, p.height, p.weight, p.birthdate\r\nfrom player p, nationality n\r\nwhere p.nationality_id=n.nationality_id && p.status=1;";
                conn = new MySqlConnection(connectionstring);
                cmd = new MySqlCommand(query, conn);
                adapter = new MySqlDataAdapter(cmd);
                adapter.Fill(dt4);
                dgv.DataSource = dt4;
                dgv.ClearSelection();

            query = $"select m.manager_id, m.manager_name, n.nation, m.birthdate FROM manager m left join nationality n ON n.nationality_id = m.nationality_id WHERE m.working = 0;";
            conn = new MySqlConnection(connectionstring);
                cmd = new MySqlCommand(query, conn);
                adapter = new MySqlDataAdapter(cmd);
                adapter.Fill(dt6);
                dgv_allmanager.DataSource = dt6;
                dgv_allmanager.ClearSelection();

        }

        private void button_add_Click(object sender, EventArgs e)
        {

                if (textbox_name.Text == ""|| textbox_number.Text == ""|| textbox_position.Text == "" || textbox_height.Text == "" || textbox_weight.Text == "" || textbox_playerid.Text == "" )
                {
                    MessageBox.Show("Fill it all!", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
                else
                {
                    string nama = textbox_name.Text;
                    string nomer = textbox_number.Text;
                    string national = combobox_nationality.SelectedValue.ToString();
                    string pos = textbox_position.Text;
                    string height = textbox_height.Text;
                    string weight = textbox_weight.Text;
                    string birthdate = dateTimePicker1.Value.ToString("yyyy-MM-dd");
                    string teamname = combobox_teamname.SelectedValue.ToString();
                    string playerid = textbox_playerid.Text;
                    query = $"insert into player values ('{playerid}', '{nomer}', '{nama}', '{national}', '{pos}','{height}', '{weight}', '{birthdate}', '{teamname}', 1, 0);";
                    executeSQL(query);
                    textbox_name.Text = "";
                    textbox_number.Text = "";
                    textbox_position.Text = "";
                    textbox_height.Text = "";
                    textbox_weight.Text = "";
                    textbox_playerid.Text = "";
                    dgv.ClearSelection();
                }
        }
        private void button_edit_Click(object sender, EventArgs e)
        {
            if (combobox_teamname2.Text != "")
            {
                if (dgv_allmanager.SelectedRows.Count != 0)
                {
                   
                    string id = dgv_allmanager.CurrentRow.Cells[0].Value.ToString();
                    query = $"update team set manager_id = '" + id + "' WHERE team_id = '" + combobox_teamname2.SelectedValue + "';";
                    executeSQL3(query);
                    string id2 = dgv_manager.CurrentRow.Cells[0].Value.ToString();
                    query = $"update manager set working = 0 WHERE manager_id = '" + id2 + "';";
                    executeSQL3(query);
                    query = $"update manager set working = 1 WHERE manager_id =  '" + id + "';";
                    executeSQL3(query);
                    updateDgvManager();
                    dgv_allmanager.ClearSelection();

                }
                else
                {
                    MessageBox.Show("Pick a Manager!", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            }
            else
            {
                MessageBox.Show("Pick a Team!", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }
        private void combobox_teamname2_SelectedIndexChanged(object sender, EventArgs e)
        { 
            string team = combobox_teamname2.SelectedValue.ToString();
            dt5.Clear();
            query = $"select m.manager_id, m.manager_name, t.team_name, m.birthdate, n.nation\r\nfrom manager m, team t, nationality n\r\nwhere t.manager_id=m.manager_id && n.nationality_id=m.nationality_id && t.team_id = '{team}' && t.team_name is not null;";
            conn = new MySqlConnection(connectionstring);
            cmd = new MySqlCommand(query, conn);
            adapter = new MySqlDataAdapter(cmd);
            adapter.Fill(dt5);
            dgv_manager.DataSource = dt5;
            dgv_manager.ClearSelection();


        }

        private void combobox_teamname3_SelectedIndexChanged(object sender, EventArgs e)
        {
                dt4.Clear();
                if (combobox_teamname3.SelectedItem != null)
                {
                    string team = combobox_teamname3.SelectedValue.ToString();
                    query = $"select p.player_name, p.team_number, n.nation, p.playing_pos, p.height, p.weight, p.birthdate, t.team_name\r\nfrom player p join nationality n on p.nationality_id=n.nationality_id\r\njoin team t on t.team_id=p.team_id\r\nwhere p.status=1 && t.team_id = '{team}';";
                    conn = new MySqlConnection(connectionstring);
                    cmd = new MySqlCommand(query, conn);
                    adapter = new MySqlDataAdapter(cmd);
                    adapter.Fill(dt4);
                    dgv.DataSource = dt4;
                    dgv.ClearSelection();
                }

        }


        private void button_delete_Click(object sender, EventArgs e)
        {

                int rows = dt4.Rows.Count;
                //MessageBox.Show(rows.ToString());
                if (combobox_teamname3.SelectedItem != null)
                {
                    if (rows >= 11)
                    {

                        if (dgv.SelectedRows.Count != 0)
                        {
                            string nama = dgv.SelectedRows[0].Cells["player_name"].Value.ToString();
                            query = $"update player set status = 0 where player_name = '{nama}';";
                            executeSQL2(query);
                            dgv.ClearSelection();
                            combobox_teamname3.SelectedIndexChanged -= combobox_teamname3_SelectedIndexChanged;
                            combobox_teamname3.SelectedItem = null;
                            combobox_teamname3.SelectedIndexChanged += combobox_teamname3_SelectedIndexChanged;

                        }
                        else
                        {
                            MessageBox.Show("Select the Player!", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        }
                    }
                    else
                    {
                        MessageBox.Show("Total Player is under 11!", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    }
                }
                else
                {
                    MessageBox.Show("Select the Team!", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
        }


    }
}
