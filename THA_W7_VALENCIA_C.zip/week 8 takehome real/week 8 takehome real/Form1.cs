﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace week_8_takehome_real
{
    public partial class Form1 : Form
    {
        string path = @".\Week 8 Poster\nama poster sinopsis.txt";
        public List<string> movieTitles = new List<string>();
        public List<string> moviePosters = new List<string>();
        public List<string> MovieSinopsis = new List<string>();
        public Dictionary<string, List<string>> filmSeatMap = new Dictionary<string, List<string>>();
        public Form1()
        {
            InitializeComponent();
        }


        public void Form1_Load(object sender, EventArgs e)
        {
           
            using (StreamReader sr = new StreamReader(path))
            {
                string line;
                while ((line = sr.ReadLine()) != null)
                {
                    string[] parts = line.Split(',');
                    if (parts.Length == 3)
                    {
                        movieTitles.Add(parts[0]);
                        moviePosters.Add(parts[1]);
                        MovieSinopsis.Add(parts[2]);
                    }
                }
            }

            int count = 0;
            for (int i = 0; i < movieTitles.Count; i++)
            {
                PictureBox picturebox = new PictureBox();
                picturebox.Image = Image.FromFile(moviePosters[i]);
                picturebox.Size = new Size(200, 200);
                picturebox.SizeMode = PictureBoxSizeMode.Zoom;
                picturebox.Tag = i;
                picturebox.Location = new Point((count % 4) * 200 + 12, (count / 4) * 250 + 40);
                picturebox.Click += Picturebox_Click;
                this.panel_show.Controls.Add(picturebox);
                count++;

                Label label = new Label();
                label.Text = movieTitles[i];
                label.Font = new Font("Century", 8, FontStyle.Regular);
                label.AutoSize = true;
                label.TextAlign = ContentAlignment.MiddleCenter;
                label.Location = new Point(picturebox.Left + 65, picturebox.Bottom + 5);
                this.panel_show.Controls.Add(label);

                //israndom.Add(i, false);
            }

        }

        private void Picturebox_Click(object sender, EventArgs e)
        {
            PictureBox picturebox = sender as PictureBox;
            string namafilm = picturebox.Tag as string;
            int index = (int)picturebox.Tag;

            Form2 form2 = new Form2(index, movieTitles, moviePosters, MovieSinopsis, filmSeatMap);
            form2.pictureboxform2 = picturebox;
            form2.Dock = DockStyle.Fill;
            form2.TopLevel = false;
            form2.ControlBox = false;
            form2.FormBorderStyle = FormBorderStyle.None;
            this.panel_show.Controls.Clear();
            this.panel_show.Controls.Add(form2);
            form2.Show();
        }
    }
}
