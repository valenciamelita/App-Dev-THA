﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Reflection.Emit;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace week_8_takehome_real
{
    public partial class Form2 : Form
    {
        Dictionary<string, List<string>> filmSeatMap = new Dictionary<string, List<string>>();
        private int index;
        public PictureBox pictureboxform2;
        private List<string> movieTitles;
        private List<string> moviePosters;
        private List<string> MovieSinopsis;


        public Form2(int index, List<string> movieTitles, List<string> moviePosters, List<string> MovieSinopsis, Dictionary<string, List<string>> filmSeatMap)
        {
            InitializeComponent();
            this.index = index;
            this.movieTitles = movieTitles;
            this.moviePosters = moviePosters;
            this.MovieSinopsis = MovieSinopsis;
            this.filmSeatMap = filmSeatMap;
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            pictureBox1.Image = Image.FromFile(moviePosters[index]);
            pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;

            label1.Text = movieTitles[index];
            label1.Font = new Font("Century", 10, FontStyle.Regular);
            label1.AutoSize = true;
            label1.TextAlign = ContentAlignment.MiddleCenter;
            label1.Location = new Point(pictureBox1.Left + 20, pictureBox1.Bottom + 10);

            label2.Text = MovieSinopsis[index];
            label2.Size = new Size(200, 100);
            label2.Font = new Font("Century", 8, FontStyle.Regular);
            label2.MaximumSize = new Size(this.Width - 20, 0);
            
        }

        private void button_back_Click(object sender, EventArgs e)
        {

            Form1 form = new Form1();
            form.Dock = DockStyle.Fill;
            form.TopLevel = false;
            form.ControlBox = false;
            form.filmSeatMap = this.filmSeatMap;
            form.FormBorderStyle = FormBorderStyle.None;
            this.panel_show.Controls.Clear();
            this.panel_show.Controls.Add(form);
            form.Show();
        }

        private void button_Click(object sender, EventArgs e)
        {
            Button btn = sender as Button;
            string jam = btn.Text;
            string jamke = Convert.ToString(btn.Tag);
            Form3 form3 = new Form3(index, movieTitles, moviePosters, MovieSinopsis, jam, jamke, filmSeatMap);
            form3.Dock = DockStyle.Fill;
            form3.TopLevel = false;
            form3.ControlBox = false;
            form3.FormBorderStyle = FormBorderStyle.None;
            this.panel_show.Controls.Clear();
            this.panel_show.Controls.Add(form3);
            form3.Show();
        }
    }


}

