﻿namespace week_8_takehome_real
{
    partial class Form3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel_show = new System.Windows.Forms.Panel();
            this.button_balikform2 = new System.Windows.Forms.Button();
            this.button_clear = new System.Windows.Forms.Button();
            this.button_reserve = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label_select = new System.Windows.Forms.Label();
            this.panel_show.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel_show
            // 
            this.panel_show.AutoScroll = true;
            this.panel_show.BackColor = System.Drawing.Color.AntiqueWhite;
            this.panel_show.Controls.Add(this.label_select);
            this.panel_show.Controls.Add(this.button_balikform2);
            this.panel_show.Controls.Add(this.button_clear);
            this.panel_show.Controls.Add(this.button_reserve);
            this.panel_show.Controls.Add(this.label1);
            this.panel_show.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel_show.Location = new System.Drawing.Point(0, 0);
            this.panel_show.Name = "panel_show";
            this.panel_show.Size = new System.Drawing.Size(1176, 746);
            this.panel_show.TabIndex = 0;
            // 
            // button_balikform2
            // 
            this.button_balikform2.Location = new System.Drawing.Point(12, 12);
            this.button_balikform2.Name = "button_balikform2";
            this.button_balikform2.Size = new System.Drawing.Size(97, 34);
            this.button_balikform2.TabIndex = 4;
            this.button_balikform2.Text = "Back";
            this.button_balikform2.UseVisualStyleBackColor = true;
            this.button_balikform2.Click += new System.EventHandler(this.button_balikform2_Click);
            // 
            // button_clear
            // 
            this.button_clear.Location = new System.Drawing.Point(1053, 940);
            this.button_clear.Name = "button_clear";
            this.button_clear.Size = new System.Drawing.Size(123, 45);
            this.button_clear.TabIndex = 2;
            this.button_clear.Text = "Reset";
            this.button_clear.UseVisualStyleBackColor = true;
            this.button_clear.Click += new System.EventHandler(this.button_clear_Click);
            // 
            // button_reserve
            // 
            this.button_reserve.Location = new System.Drawing.Point(83, 940);
            this.button_reserve.Name = "button_reserve";
            this.button_reserve.Size = new System.Drawing.Size(123, 45);
            this.button_reserve.TabIndex = 1;
            this.button_reserve.Text = "Reserve";
            this.button_reserve.UseVisualStyleBackColor = true;
            this.button_reserve.Click += new System.EventHandler(this.button_reserve_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Glacial Indifference", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(408, 991);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(502, 43);
            this.label1.TabIndex = 0;
            this.label1.Text = "-------- SCREEN AREA --------";
            // 
            // label_select
            // 
            this.label_select.AutoSize = true;
            this.label_select.Location = new System.Drawing.Point(60, 917);
            this.label_select.Name = "label_select";
            this.label_select.Size = new System.Drawing.Size(118, 20);
            this.label_select.TabIndex = 5;
            this.label_select.Text = "Selected Seat: ";
            // 
            // Form3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1176, 746);
            this.Controls.Add(this.panel_show);
            this.Name = "Form3";
            this.Text = "Form3";
            this.Load += new System.EventHandler(this.Form3_Load);
            this.panel_show.ResumeLayout(false);
            this.panel_show.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel_show;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button button_reserve;
        private System.Windows.Forms.Button button_balikform2;
        private System.Windows.Forms.Button button_clear;
        private System.Windows.Forms.Label label_select;
    }
}