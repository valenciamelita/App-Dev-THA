﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Reflection;
using System.Reflection.Emit;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.Rebar;
using Label = System.Windows.Forms.Label;

namespace week_8_takehome_real
{
    public partial class Form3 : Form
    {
        Dictionary<string, List<string>> filmSeatMap = new Dictionary<string, List<string>>();
        List<Button> listbutton = new List<Button>();
        List<Button> listredbutton = new List<Button>();
        List<Button> listselectedbutton = new List<Button>();
        private int index;
        private List<string> movieTitles;
        private List<string> moviePosters;
        private List<string> MovieSinopsis;
        string jam;
        string jamke;

        public Form3(int index, List<string> movieTitles, List<string> moviePosters, List<string> MovieSinopsis, string jam, string jamke, Dictionary<string, List<string>> filmSeatMap)
        {
            InitializeComponent();
            this.index = index;
            this.movieTitles = movieTitles;
            this.moviePosters = moviePosters;
            this.MovieSinopsis = MovieSinopsis;
            this.jam = jam;
            this.jamke = jamke;
            this.filmSeatMap = filmSeatMap;
        }

        private void Form3_Load(object sender, EventArgs e)
        {
            string filmdanjam = $"{Convert.ToString(index)} {jamke}";
            Label labeljam = new Label();
            labeljam.Location = new Point(350, 60);
            labeljam.Text = $" {movieTitles[index]}   {jam} ";
            labeljam.Font = new Font("Century", 10, FontStyle.Regular);
            labeljam.AutoSize = true;
            labeljam.TextAlign = ContentAlignment.MiddleCenter;
            this.panel_show.Controls.Add(labeljam);

            

            char col = 'A';
            for (int i = 0; i < 10; i++)
            {
                for (int j = 0; j < 10; j++)
                {
                    Button button = new Button();
                    button.Size = new Size(50,50);
                    button.Text = $"{col} {j + 1}";
                    button.Location = new Point(50 * j + 180, 50 * i + 100);
                    this.panel_show.Controls.Add(button);
                    this.listbutton.Add(button);
                    button.Click += Button_Click;
                }
                col++;
            }


            if (filmSeatMap.ContainsKey(filmdanjam))
            {
                List<string> kursimerah = filmSeatMap[filmdanjam];
                foreach (string kursi in kursimerah)
                {
                    int index = listbutton.FindIndex(button => button.Text == kursi);
                    listbutton[index].BackColor = Color.Red;
                }
            }
            else
            {
                List<string> kursimerah = new List<string>();
                Random rnd = new Random();
                int num = rnd.Next(0, 71);
                for (int i = 0; i < num; i++)
                {
                    int randIndex = rnd.Next(0, 100);
                    listbutton[randIndex].BackColor = Color.Red;
                    kursimerah.Add(listbutton[randIndex].Text);
                }
                filmSeatMap[filmdanjam] = kursimerah;
            }

            foreach (Button button in listbutton)
            {
                if (button.BackColor != Color.Red)
                {
                    button.BackColor = Color.MediumSpringGreen;
                }  
            }
        }

        private void Button_Click(object sender, EventArgs e)
        {
            Button clickedButton = sender as Button;
            if (clickedButton.BackColor == Color.Red)
            {
                MessageBox.Show("This Seat is Reserved!","Error",MessageBoxButtons.OK,MessageBoxIcon.Warning);
            }
            else if (clickedButton.BackColor == Color.MediumSpringGreen)
            {
                clickedButton.BackColor = Color.Gold;
                listselectedbutton.Add(clickedButton);
                string selectedSeats = string.Join(", ", listselectedbutton.Select(button => button.Text));
                label_select.Text = $"Selected Seat: {selectedSeats}";          
            }
            else if (clickedButton.BackColor == Color.Gold)
            {
                clickedButton.BackColor= Color.MediumSpringGreen;
                listselectedbutton.Remove(clickedButton);
                string selectedSeats = string.Join(", ", listselectedbutton.Select(button => button.Text));
                label_select.Text = $"Selected Seat: {selectedSeats}";
            }
        }

        private void button_balikform2_Click(object sender, EventArgs e)
        {
            Form2 form2 = new Form2(index, movieTitles, moviePosters, MovieSinopsis, filmSeatMap);
            form2.Dock = DockStyle.Fill;
            form2.TopLevel = false;
            form2.ControlBox = false;
            form2.FormBorderStyle = FormBorderStyle.None;
            this.panel_show.Controls.Clear();
            this.panel_show.Controls.Add(form2);
            form2.Show();
        }

        private void button_reserve_Click(object sender, EventArgs e)
        {
            List<string> kursimerah = new List<string>();
            string selectedSeats = string.Join(", ", listselectedbutton.Select(button => button.Text));
            if (listselectedbutton.Count == 0)
            {
                MessageBox.Show("Please select at least one seat to reserve.", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else
            {
                DialogResult result = MessageBox.Show($"You have reserved the following seats: {selectedSeats}", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (result == DialogResult.Yes)
                {
                    MessageBox.Show("You have successfully reserved the seat!", "OK", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    foreach (Button button in listselectedbutton)
                    {
                        button.BackColor = Color.Red;
                    }
                    foreach(Button button in listbutton)
                    {
                        if (button.BackColor == Color.Red)
                        {
                            kursimerah.Add(button.Text);
                        }
                    }
                    
                    string filmdanjam = $"{Convert.ToString(index)} {jamke}";
                    filmSeatMap[filmdanjam] = kursimerah;
                    listselectedbutton.Clear();
                    selectedSeats = "";
                    label_select.Text = $"Selected Seat: {selectedSeats}";
                }
                else
                {
                    listselectedbutton.Clear();
                    label_select.Text = $"Selected Seat: {selectedSeats}";
                }

            }
        }

        private void button_clear_Click(object sender, EventArgs e)
        {
            List<string> kursimerah = new List<string>();
            DialogResult result = MessageBox.Show("You want to clear all the seats and reset?", "Confirmation", MessageBoxButtons.OKCancel, MessageBoxIcon.Question);
            if (result == DialogResult.OK)
            {
                foreach (Button button in listbutton)
                {
                    button.BackColor = Color.MediumSpringGreen;
                    listredbutton.Clear();
                    listselectedbutton.Clear();
                }
            }
            foreach (Button button in listbutton)
            {
                if (button.BackColor == Color.Red)
                {
                    kursimerah.Add(button.Text);
                }
            }
            string filmdanjam = $"{Convert.ToString(index)} {jamke}";
            filmSeatMap[filmdanjam] = kursimerah;
        }
    }
}
