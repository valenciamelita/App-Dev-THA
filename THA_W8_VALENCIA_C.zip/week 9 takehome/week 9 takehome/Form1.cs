﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data;
using MySql.Data.MySqlClient;

namespace week_9_takehome
{
    public partial class Form1 : Form
    {
        string connectionstring = "server=localhost;uid=root;pwd=junior123;database=premier_league";
        MySqlConnection conn;
        MySqlCommand cmd; 
        MySqlDataAdapter adapter;
        string query;
        DataTable dt;
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            dt = new DataTable();
            query = "select team_id from team;";
            conn = new MySqlConnection(connectionstring);
            cmd = new MySqlCommand(query, conn);
            adapter = new MySqlDataAdapter(cmd);
            adapter.Fill(dt);
        }


        private void playerDataToolStripMenuItem_Click(object sender, EventArgs e)
        {

            Player_Data playerdata = new Player_Data();
            playerdata.Dock = DockStyle.Fill;
            playerdata.TopLevel = false;
            playerdata.ControlBox = false;
            playerdata.FormBorderStyle = FormBorderStyle.None;
            this.panel1.Controls.Clear();
            this.panel1.Controls.Add(playerdata);
            playerdata.Show();
        }

        private void showMatchDetailsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ShowMatch showmatch = new ShowMatch();
            showmatch.Dock = DockStyle.Fill;
            showmatch.TopLevel = false;
            showmatch.ControlBox = false;
            showmatch.FormBorderStyle = FormBorderStyle.None;
            this.panel1.Controls.Clear();
            this.panel1.Controls.Add(showmatch);
            showmatch.Show();

        }
    }
}
