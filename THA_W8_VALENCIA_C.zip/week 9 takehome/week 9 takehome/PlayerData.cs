﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace week_9_takehome
{
    public partial class Player_Data : Form
    {
        string connectionstring = "server=localhost;uid=root;pwd=junior123;database=premier_league";
        MySqlConnection conn;
        MySqlCommand cmd;
        MySqlDataAdapter adapter;
        string query;
        DataTable dt;
        DataTable dtplayer;
        DataTable dt2;
        DataTable dt3;
        public Player_Data()
        {
            InitializeComponent();
        }

        private void Player_Data_Load(object sender, EventArgs e)
        {
            
            dt = new DataTable();
            query = "select team_name from team;";
            conn = new MySqlConnection(connectionstring);
            cmd = new MySqlCommand(query, conn);
            adapter = new MySqlDataAdapter(cmd);
            adapter.Fill(dt);

            combobox_team.DataSource = dt;
            combobox_team.DisplayMember = "team_name";
            combobox_team.SelectedIndex = -1;


        }

        private void combobox_team_SelectedIndexChanged(object sender, EventArgs e)
        {
            dtplayer = new DataTable();
            query = $"select p.player_name from player p, team t where t.team_id = p.team_id && t.team_name = '{combobox_team.Text}' ;";
            conn = new MySqlConnection(connectionstring);
            cmd = new MySqlCommand(query, conn);
            adapter = new MySqlDataAdapter(cmd);
            adapter.Fill(dtplayer);

            combobox_player.DataSource = dtplayer;
            combobox_player.DisplayMember = "player_name";
            combobox_player.SelectedIndex = -1;
        }

        private void button_submit_Click(object sender, EventArgs e)
        {
            if (combobox_player.SelectedIndex == -1||combobox_team.SelectedIndex == -1)
            {
                MessageBox.Show("Pick first!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else
            {
                dt2 = new DataTable();
                query = $"SELECT p.player_name,t.team_name,case p.playing_pos when 'G' then 'GoalKeeper' when 'M' then 'MidFielder' when 'D' then 'Defender' when 'F' then 'Forward' end as 'Position',n.nation,p.team_number FROM player p,nationality n, team t WHERE p.team_id=t.team_id && n.nationality_id=p.nationality_id && t.team_name= '{combobox_team.Text}' && p.player_name='{combobox_player.Text}';";
                conn = new MySqlConnection(connectionstring);
                cmd = new MySqlCommand(query, conn);
                adapter = new MySqlDataAdapter(cmd);
                adapter.Fill(dt2);

                label_name.Text = combobox_player.Text;
                label_team.Text = combobox_team.Text;
                label_position.Text = dt2.Rows[0]["Position"].ToString();
                label_nationality.Text = dt2.Rows[0]["nation"].ToString();
                label_number.Text = dt2.Rows[0]["team_number"].ToString();

                dt3 = new DataTable();
                query = $"select p.player_name, t.team_name,\r\nifnull(count(case when d.type ='CY' then 1 end), 0) as 'yellow_card',\r\nifnull(count(case when d.type ='CR' then 1 end), 0) as 'red_card',\r\nifnull(count(case when d.type ='GO' then 1 end), 0) as 'goal_scored',\r\nifnull(count(case when d.type ='PM' then 1 end), 0) as 'penalty_missed'\r\nfrom player p\r\nleft join dmatch d on p.player_id = d.player_id\r\nleft join team t on t.team_id = p.team_id where p.player_name = '{combobox_player.Text}' group by p.player_name, t.team_name;";
                conn = new MySqlConnection(connectionstring);
                cmd = new MySqlCommand(query, conn);
                adapter = new MySqlDataAdapter(cmd);
                adapter.Fill(dt3);

                label_yellow.Text = dt3.Rows[0]["yellow_card"].ToString();
                label_red.Text = dt3.Rows[0]["red_card"].ToString();
                label_goal.Text = dt3.Rows[0]["goal_scored"].ToString();
                label_missed.Text = dt3.Rows[0]["penalty_missed"].ToString();
            }
            
        }
    }
}
