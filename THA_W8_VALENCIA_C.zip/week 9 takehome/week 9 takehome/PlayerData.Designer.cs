﻿namespace week_9_takehome
{
    partial class Player_Data
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.label_missed = new System.Windows.Forms.Label();
            this.label_goal = new System.Windows.Forms.Label();
            this.label_red = new System.Windows.Forms.Label();
            this.label_yellow = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label_number = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label_nationality = new System.Windows.Forms.Label();
            this.label_position = new System.Windows.Forms.Label();
            this.label_team = new System.Windows.Forms.Label();
            this.label_name = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.combobox_player = new System.Windows.Forms.ComboBox();
            this.combobox_team = new System.Windows.Forms.ComboBox();
            this.button_submit = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.label_missed);
            this.panel1.Controls.Add(this.label_goal);
            this.panel1.Controls.Add(this.label_red);
            this.panel1.Controls.Add(this.label_yellow);
            this.panel1.Controls.Add(this.label10);
            this.panel1.Controls.Add(this.label9);
            this.panel1.Controls.Add(this.label8);
            this.panel1.Controls.Add(this.label7);
            this.panel1.Controls.Add(this.label_number);
            this.panel1.Controls.Add(this.label12);
            this.panel1.Controls.Add(this.label_nationality);
            this.panel1.Controls.Add(this.label_position);
            this.panel1.Controls.Add(this.label_team);
            this.panel1.Controls.Add(this.label_name);
            this.panel1.Controls.Add(this.label6);
            this.panel1.Controls.Add(this.label5);
            this.panel1.Controls.Add(this.label4);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.combobox_player);
            this.panel1.Controls.Add(this.combobox_team);
            this.panel1.Controls.Add(this.button_submit);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(800, 450);
            this.panel1.TabIndex = 0;
            // 
            // label_missed
            // 
            this.label_missed.AutoSize = true;
            this.label_missed.Location = new System.Drawing.Point(545, 316);
            this.label_missed.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_missed.Name = "label_missed";
            this.label_missed.Size = new System.Drawing.Size(14, 20);
            this.label_missed.TabIndex = 40;
            this.label_missed.Text = "-";
            // 
            // label_goal
            // 
            this.label_goal.AutoSize = true;
            this.label_goal.Location = new System.Drawing.Point(545, 278);
            this.label_goal.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_goal.Name = "label_goal";
            this.label_goal.Size = new System.Drawing.Size(14, 20);
            this.label_goal.TabIndex = 39;
            this.label_goal.Text = "-";
            // 
            // label_red
            // 
            this.label_red.AutoSize = true;
            this.label_red.Location = new System.Drawing.Point(545, 233);
            this.label_red.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_red.Name = "label_red";
            this.label_red.Size = new System.Drawing.Size(14, 20);
            this.label_red.TabIndex = 38;
            this.label_red.Text = "-";
            // 
            // label_yellow
            // 
            this.label_yellow.AutoSize = true;
            this.label_yellow.Location = new System.Drawing.Point(545, 190);
            this.label_yellow.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_yellow.Name = "label_yellow";
            this.label_yellow.Size = new System.Drawing.Size(14, 20);
            this.label_yellow.TabIndex = 37;
            this.label_yellow.Text = "-";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Century", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(394, 316);
            this.label10.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(122, 20);
            this.label10.TabIndex = 36;
            this.label10.Text = "Penalty Missed";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Century", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(394, 278);
            this.label9.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(96, 20);
            this.label9.TabIndex = 35;
            this.label9.Text = "Goal Scored";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Century", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(394, 233);
            this.label8.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(79, 20);
            this.label8.TabIndex = 34;
            this.label8.Text = "Red Card";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Century", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(394, 190);
            this.label7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(98, 20);
            this.label7.TabIndex = 33;
            this.label7.Text = "Yellow Card";
            // 
            // label_number
            // 
            this.label_number.AutoSize = true;
            this.label_number.Location = new System.Drawing.Point(191, 372);
            this.label_number.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_number.Name = "label_number";
            this.label_number.Size = new System.Drawing.Size(14, 20);
            this.label_number.TabIndex = 32;
            this.label_number.Text = "-";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Century", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(49, 372);
            this.label12.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(121, 20);
            this.label12.TabIndex = 31;
            this.label12.Text = "Squad Number";
            // 
            // label_nationality
            // 
            this.label_nationality.AutoSize = true;
            this.label_nationality.Location = new System.Drawing.Point(191, 326);
            this.label_nationality.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_nationality.Name = "label_nationality";
            this.label_nationality.Size = new System.Drawing.Size(14, 20);
            this.label_nationality.TabIndex = 30;
            this.label_nationality.Text = "-";
            // 
            // label_position
            // 
            this.label_position.AutoSize = true;
            this.label_position.Location = new System.Drawing.Point(191, 278);
            this.label_position.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_position.Name = "label_position";
            this.label_position.Size = new System.Drawing.Size(14, 20);
            this.label_position.TabIndex = 29;
            this.label_position.Text = "-";
            // 
            // label_team
            // 
            this.label_team.AutoSize = true;
            this.label_team.Location = new System.Drawing.Point(191, 233);
            this.label_team.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_team.Name = "label_team";
            this.label_team.Size = new System.Drawing.Size(14, 20);
            this.label_team.TabIndex = 28;
            this.label_team.Text = "-";
            // 
            // label_name
            // 
            this.label_name.AutoSize = true;
            this.label_name.Location = new System.Drawing.Point(191, 190);
            this.label_name.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_name.Name = "label_name";
            this.label_name.Size = new System.Drawing.Size(14, 20);
            this.label_name.TabIndex = 27;
            this.label_name.Text = "-";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Century", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(49, 326);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(94, 20);
            this.label6.TabIndex = 26;
            this.label6.Text = "Nationality";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Century", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(49, 278);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(69, 20);
            this.label5.TabIndex = 25;
            this.label5.Text = "Position";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Century", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(49, 233);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(51, 20);
            this.label4.TabIndex = 24;
            this.label4.Text = "Team";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Century", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(49, 190);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(106, 20);
            this.label3.TabIndex = 23;
            this.label3.Text = "Player Name";
            // 
            // combobox_player
            // 
            this.combobox_player.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.combobox_player.FormattingEnabled = true;
            this.combobox_player.Location = new System.Drawing.Point(169, 84);
            this.combobox_player.Name = "combobox_player";
            this.combobox_player.Size = new System.Drawing.Size(176, 28);
            this.combobox_player.TabIndex = 4;
            // 
            // combobox_team
            // 
            this.combobox_team.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.combobox_team.FormattingEnabled = true;
            this.combobox_team.Location = new System.Drawing.Point(169, 39);
            this.combobox_team.Name = "combobox_team";
            this.combobox_team.Size = new System.Drawing.Size(176, 28);
            this.combobox_team.TabIndex = 3;
            this.combobox_team.SelectedIndexChanged += new System.EventHandler(this.combobox_team_SelectedIndexChanged);
            // 
            // button_submit
            // 
            this.button_submit.Location = new System.Drawing.Point(211, 136);
            this.button_submit.Name = "button_submit";
            this.button_submit.Size = new System.Drawing.Size(75, 32);
            this.button_submit.TabIndex = 2;
            this.button_submit.Text = "Submit";
            this.button_submit.UseVisualStyleBackColor = true;
            this.button_submit.Click += new System.EventHandler(this.button_submit_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Century", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(37, 84);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(110, 20);
            this.label2.TabIndex = 1;
            this.label2.Text = "Select Player:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Century", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(44, 39);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(103, 20);
            this.label1.TabIndex = 0;
            this.label1.Text = "Select Team:";
            // 
            // Player_Data
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.panel1);
            this.Name = "Player_Data";
            this.Text = "Player_Data";
            this.Load += new System.EventHandler(this.Player_Data_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label_missed;
        private System.Windows.Forms.Label label_goal;
        private System.Windows.Forms.Label label_red;
        private System.Windows.Forms.Label label_yellow;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label_number;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label_nationality;
        private System.Windows.Forms.Label label_position;
        private System.Windows.Forms.Label label_team;
        private System.Windows.Forms.Label label_name;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ComboBox combobox_player;
        private System.Windows.Forms.ComboBox combobox_team;
        private System.Windows.Forms.Button button_submit;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
    }
}