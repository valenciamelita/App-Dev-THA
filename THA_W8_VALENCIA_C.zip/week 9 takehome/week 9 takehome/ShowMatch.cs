﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace week_9_takehome
{
    public partial class ShowMatch : Form
    {
        string connectionstring = "server=localhost;uid=root;pwd=junior123;database=premier_league";
        MySqlConnection conn;
        MySqlCommand cmd;
        MySqlDataAdapter adapter;
        string query;
        DataTable dt;
        DataTable dtdate;
        DataTable dt2;
        DataTable dt3;
        DataTable dt4;
        DataTable dt5;
        public ShowMatch()
        {
            InitializeComponent();
        }

        private void ShowMatch_Load(object sender, EventArgs e)
        {
            dt = new DataTable();
            query = "select team_name from team;";
            conn = new MySqlConnection(connectionstring);
            cmd = new MySqlCommand(query, conn);
            adapter = new MySqlDataAdapter(cmd);
            adapter.Fill(dt);

            combobox_team.DataSource = dt;
            combobox_team.DisplayMember = "team_name";
            combobox_team.SelectedIndex = -1;
        }

        private void combobox_team_SelectedIndexChanged(object sender, EventArgs e)
        {
            dtdate = new DataTable();
            query = $"select m.match_date, m.match_id, t.team_name as 'team_home', t2.team_name as 'team_away'\r\nfrom `match` m, team t, team t2\r\nwhere m.team_home = t.team_id && m.team_away = t2.team_id && (t.team_name = '{combobox_team.Text}' or t2.team_name = '{combobox_team.Text}');";
            conn = new MySqlConnection(connectionstring);
            cmd = new MySqlCommand(query, conn);
            adapter = new MySqlDataAdapter(cmd);
            adapter.Fill(dtdate);

            combobox_date.DataSource = dtdate;
            combobox_date.DisplayMember = "match_date";
            combobox_date.ValueMember = "match_id";

            if (combobox_date.SelectedValue != null)
            {
                DataRowView row = (DataRowView)combobox_date.SelectedItem;
                label_home.Text = row["team_home"].ToString();
                label_away.Text = row["team_away"].ToString();
            }
            else
            {
                label_home.Text = "-";
                label_away.Text = "-";
            }
        }
        private void combobox_date_SelectedIndexChanged(object sender, EventArgs e)
        {
            dt2 = new DataTable();
            query = $"select t.team_name as 'team_home', t2.team_name as 'team_away'\r\nfrom `match` m , team t, team t2\r\nwhere m.team_home = t.team_id && m.team_away = t2.team_id && m.match_id = '{combobox_date.SelectedValue}';";
            conn = new MySqlConnection(connectionstring);
            cmd = new MySqlCommand(query, conn);
            adapter = new MySqlDataAdapter(cmd);
            adapter.Fill(dt2);

            if (combobox_date.SelectedValue != null)
            {
                DataRowView row = (DataRowView)combobox_date.SelectedItem;
                label_home.Text = row["team_home"].ToString();
                label_away.Text = row["team_away"].ToString();
            }
            else
            {
                label_home.Text = "-";
                label_away.Text = "-";
            }
        }

        private void button_submit_Click(object sender, EventArgs e)
        {
            if (combobox_team.SelectedIndex == -1)
            {
                MessageBox.Show("Pick first!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else
            {
                dt3 = new DataTable();
                query = $"select t.team_name, p.player_name, case p.playing_pos when 'G' then 'GoalKeeper' when 'M' then 'MidFielder' when 'D' then 'Defender' when 'F' then 'Forward' end as 'Position'\r\nfrom team t, player p\r\nwhere t.team_id = p.team_id && t.team_name = '{label_home.Text}';";
                conn = new MySqlConnection(connectionstring);
                cmd = new MySqlCommand(query, conn);
                adapter = new MySqlDataAdapter(cmd);
                adapter.Fill(dt3);
                dgv_home.DataSource = dt3;

                dt4 = new DataTable();
                query = $"select t.team_name, p.player_name, case p.playing_pos when 'G' then 'GoalKeeper' when 'M' then 'MidFielder' when 'D' then 'Defender' when 'F' then 'Forward' end as 'Position'\r\nfrom team t, player p\r\nwhere t.team_id = p.team_id && t.team_name = '{label_away.Text}';";
                conn = new MySqlConnection(connectionstring);
                cmd = new MySqlCommand(query, conn);
                adapter = new MySqlDataAdapter(cmd);
                adapter.Fill(dt4);
                dgv_away.DataSource = dt4;

                combobox_date.ValueMember = "match_id";

                dt5 = new DataTable();
                query = $"select d.`minute`, t.team_name, p.player_name, case d.`type` when 'CY' then 'Yellow Card (CY)' when 'CR' then 'Red Card (CR)' when 'GO' then 'Goal Scored (GO)' when 'GP' \r\nthen 'Goal Penalty (GP)' when 'GW' then 'Own Goal (GW)' when 'PM' then 'Penalty Missed (PM)' end as 'type'\r\nfrom dmatch d, player p, team t\r\nwhere t.team_id = d.team_id && p.player_id = d.player_id && d.match_id = '{combobox_date.SelectedValue}' ;";
                conn = new MySqlConnection(connectionstring);
                cmd = new MySqlCommand(query, conn);
                adapter = new MySqlDataAdapter(cmd);
                adapter.Fill(dt5);
                dgv_details.DataSource = dt5;
            }
           
        }
    }    
}
