﻿namespace week_9_takehome
{
    partial class ShowMatch
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.combobox_team = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.combobox_date = new System.Windows.Forms.ComboBox();
            this.button_submit = new System.Windows.Forms.Button();
            this.dgv_home = new System.Windows.Forms.DataGridView();
            this.dgv_away = new System.Windows.Forms.DataGridView();
            this.dgv_details = new System.Windows.Forms.DataGridView();
            this.label_home = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label_away = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_home)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_away)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_details)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.label5);
            this.panel1.Controls.Add(this.label_away);
            this.panel1.Controls.Add(this.label4);
            this.panel1.Controls.Add(this.label_home);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.dgv_details);
            this.panel1.Controls.Add(this.dgv_away);
            this.panel1.Controls.Add(this.dgv_home);
            this.panel1.Controls.Add(this.button_submit);
            this.panel1.Controls.Add(this.combobox_date);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.combobox_team);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1179, 626);
            this.panel1.TabIndex = 0;
            // 
            // combobox_team
            // 
            this.combobox_team.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.combobox_team.FormattingEnabled = true;
            this.combobox_team.Location = new System.Drawing.Point(167, 43);
            this.combobox_team.Name = "combobox_team";
            this.combobox_team.Size = new System.Drawing.Size(176, 28);
            this.combobox_team.TabIndex = 5;
            this.combobox_team.SelectedIndexChanged += new System.EventHandler(this.combobox_team_SelectedIndexChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Century", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(44, 51);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(103, 20);
            this.label1.TabIndex = 4;
            this.label1.Text = "Select Team:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Century", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(44, 88);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(96, 20);
            this.label2.TabIndex = 6;
            this.label2.Text = "Select Date:";
            // 
            // combobox_date
            // 
            this.combobox_date.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.combobox_date.FormattingEnabled = true;
            this.combobox_date.Location = new System.Drawing.Point(167, 85);
            this.combobox_date.Name = "combobox_date";
            this.combobox_date.Size = new System.Drawing.Size(176, 28);
            this.combobox_date.TabIndex = 7;
            this.combobox_date.SelectedIndexChanged += new System.EventHandler(this.combobox_date_SelectedIndexChanged);
            // 
            // button_submit
            // 
            this.button_submit.Location = new System.Drawing.Point(389, 63);
            this.button_submit.Name = "button_submit";
            this.button_submit.Size = new System.Drawing.Size(75, 32);
            this.button_submit.TabIndex = 8;
            this.button_submit.Text = "Submit";
            this.button_submit.UseVisualStyleBackColor = true;
            this.button_submit.Click += new System.EventHandler(this.button_submit_Click);
            // 
            // dgv_home
            // 
            this.dgv_home.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgv_home.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_home.Location = new System.Drawing.Point(31, 181);
            this.dgv_home.Name = "dgv_home";
            this.dgv_home.RowHeadersVisible = false;
            this.dgv_home.RowHeadersWidth = 62;
            this.dgv_home.RowTemplate.Height = 28;
            this.dgv_home.Size = new System.Drawing.Size(521, 179);
            this.dgv_home.TabIndex = 9;
            // 
            // dgv_away
            // 
            this.dgv_away.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgv_away.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_away.Location = new System.Drawing.Point(624, 181);
            this.dgv_away.Name = "dgv_away";
            this.dgv_away.RowHeadersVisible = false;
            this.dgv_away.RowHeadersWidth = 62;
            this.dgv_away.RowTemplate.Height = 28;
            this.dgv_away.Size = new System.Drawing.Size(521, 179);
            this.dgv_away.TabIndex = 10;
            // 
            // dgv_details
            // 
            this.dgv_details.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgv_details.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_details.Location = new System.Drawing.Point(31, 406);
            this.dgv_details.Name = "dgv_details";
            this.dgv_details.RowHeadersVisible = false;
            this.dgv_details.RowHeadersWidth = 62;
            this.dgv_details.RowTemplate.Height = 28;
            this.dgv_details.Size = new System.Drawing.Size(1114, 196);
            this.dgv_details.TabIndex = 11;
            // 
            // label_home
            // 
            this.label_home.AutoSize = true;
            this.label_home.Font = new System.Drawing.Font("Century", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_home.Location = new System.Drawing.Point(147, 157);
            this.label_home.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_home.Name = "label_home";
            this.label_home.Size = new System.Drawing.Size(14, 20);
            this.label_home.TabIndex = 13;
            this.label_home.Text = "-";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Century", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(31, 158);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(98, 20);
            this.label3.TabIndex = 12;
            this.label3.Text = "Home Team";
            // 
            // label_away
            // 
            this.label_away.AutoSize = true;
            this.label_away.Font = new System.Drawing.Font("Century", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_away.Location = new System.Drawing.Point(733, 157);
            this.label_away.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_away.Name = "label_away";
            this.label_away.Size = new System.Drawing.Size(14, 20);
            this.label_away.TabIndex = 15;
            this.label_away.Text = "-";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Century", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(620, 157);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(96, 20);
            this.label4.TabIndex = 14;
            this.label4.Text = "Away Team";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Century", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(31, 383);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(61, 20);
            this.label5.TabIndex = 16;
            this.label5.Text = "Details";
            // 
            // ShowMatch
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.ClientSize = new System.Drawing.Size(1179, 626);
            this.Controls.Add(this.panel1);
            this.Name = "ShowMatch";
            this.Text = "ShowMatch";
            this.Load += new System.EventHandler(this.ShowMatch_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_home)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_away)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_details)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.ComboBox combobox_date;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox combobox_team;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button button_submit;
        private System.Windows.Forms.DataGridView dgv_home;
        private System.Windows.Forms.Label label_home;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.DataGridView dgv_details;
        private System.Windows.Forms.DataGridView dgv_away;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label_away;
        private System.Windows.Forms.Label label4;
    }
}